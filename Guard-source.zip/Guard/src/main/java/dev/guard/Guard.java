package dev.guard;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.player.*;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.*;

public final class Guard extends JavaPlugin implements Listener {

    private static final class Data {
        double vl;
        Location lastGround;
        int air, water, mined, ores;
        double climb;
        long lastVelocity, lastTeleport;
        final ArrayDeque<Long> swings = new ArrayDeque<>();
        final ArrayDeque<Long> breaks = new ArrayDeque<>();
        final Map<String, Long> alerts = new HashMap<>();
        final Set<UUID> hidden = new HashSet<>();
    }

    private static final Set<Material> SPECIAL = EnumSet.of(Material.COBWEB, Material.SWEET_BERRY_BUSH,
            Material.HONEY_BLOCK, Material.POWDER_SNOW, Material.BUBBLE_COLUMN, Material.SLIME_BLOCK);
    private static final Set<Material> ICE = EnumSet.of(Material.ICE, Material.PACKED_ICE,
            Material.BLUE_ICE, Material.FROSTED_ICE);
    private static final Set<Material> VALUABLE = EnumSet.of(Material.DIAMOND_ORE, Material.DEEPSLATE_DIAMOND_ORE,
            Material.ANCIENT_DEBRIS, Material.EMERALD_ORE, Material.DEEPSLATE_EMERALD_ORE);
    private static final double[] OFF = {0, 0.31, -0.31};
    private static final double[] HS = {0.1, 0.9, 1.7};
    private static final double[][] OFFS = {{0, 0}, {0.3, 0.3}, {-0.3, 0.3}, {0.3, -0.3}, {-0.3, -0.3}};

    private final Map<UUID, Data> data = new HashMap<>();
    private double kickVl, reachLimit, espMax;
    private int maxCps;
    private boolean esp;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadCfg();
        getServer().getPluginManager().registerEvents(this, this);
        getServer().getScheduler().runTaskTimer(this,
                () -> data.values().forEach(x -> x.vl = Math.max(0, x.vl - 1)), 20, 20);
        if (esp) {
            int iv = Math.max(1, getConfig().getInt("esp.interval-ticks", 5));
            getServer().getScheduler().runTaskTimer(this, this::espTick, 20, iv);
        }
    }

    private void loadCfg() {
        kickVl = getConfig().getDouble("kick-vl", 40);
        maxCps = getConfig().getInt("max-cps", 22);
        reachLimit = getConfig().getDouble("reach-limit", 3.7);
        esp = getConfig().getBoolean("esp.enabled", true);
        espMax = getConfig().getDouble("esp.max-distance", 96);
    }

    private Data d(Player p) {
        return data.computeIfAbsent(p.getUniqueId(), k -> {
            Data x = new Data();
            x.lastGround = p.getLocation();
            return x;
        });
    }

    private boolean exempt(Player p) {
        GameMode g = p.getGameMode();
        return g == GameMode.CREATIVE || g == GameMode.SPECTATOR || p.getAllowFlight()
                || p.isInsideVehicle() || p.isDead() || p.hasPermission("guard.bypass");
    }

    // ---------------------------------------------------------------- movement
    @EventHandler(ignoreCancelled = true)
    @SuppressWarnings("deprecation")
    public void onMove(PlayerMoveEvent e) {
        if (!e.hasChangedPosition()) return;
        Player p = e.getPlayer();
        if (exempt(p)) return;
        Location from = e.getFrom(), to = e.getTo();
        Data d = d(p);
        long now = System.currentTimeMillis();
        boolean grace = now - d.lastVelocity < 2000 || now - d.lastTeleport < 2000;
        double dy = to.getY() - from.getY();
        double hor = Math.hypot(to.getX() - from.getX(), to.getZ() - from.getZ());
        boolean ground = nearGround(to), special = special(to);
        boolean bad = false;

        // FLY / NOFALL / GROUND-SPOOF
        if (ground || special) {
            d.air = 0;
            d.climb = 0;
            d.lastGround = to.clone();
        } else if (grace) {
            d.air = 0;
            d.climb = 0;
        } else if (!p.isGliding() && !p.isRiptiding()
                && !p.hasPotionEffect(PotionEffectType.LEVITATION)
                && !p.hasPotionEffect(PotionEffectType.SLOW_FALLING)) {
            d.air++;
            if (dy > 0) d.climb += dy;
            PotionEffect jb = p.getPotionEffect(PotionEffectType.JUMP_BOOST);
            double maxClimb = 1.35 + (jb == null ? 0 : (jb.getAmplifier() + 1) * 0.55);
            if (p.isOnGround() && !onEntity(p)) {
                flag(p, d, "Fly/NoFall (ground spoof)", 3, true);
                bad = true;
            } else if (d.climb > maxClimb) {
                flag(p, d, "Fly (climb)", 3, true);
                bad = true;
            } else if (d.air > 12 && dy > -0.03) {
                flag(p, d, "Fly (hover)", 2, true);
                bad = true;
            }
        }

        // SPEED
        if (!grace && !p.isGliding() && !p.isRiptiding()) {
            PotionEffect sp = p.getPotionEffect(PotionEffectType.SPEED);
            double limit = 0.40 * (p.getWalkSpeed() / 0.2) * (1 + 0.2 * (sp == null ? 0 : sp.getAmplifier() + 1));
            if (ICE.contains(to.clone().subtract(0, 0.5, 0).getBlock().getType())) limit *= 1.8;
            if (hor > limit + 0.12) {
                flag(p, d, "Speed", 1.5, true);
                bad = true;
            }
        }

        // JESUS (walking on water)
        Block feet = to.getBlock();
        Block below = to.clone().subtract(0, 0.1, 0).getBlock();
        if (below.getType() == Material.WATER && !feet.isLiquid() && feet.getType() != Material.LILY_PAD
                && !p.isSwimming() && Math.abs(dy) < 0.005 && hor > 0.05) {
            if (++d.water > 8) {
                flag(p, d, "Jesus", 2, true);
                bad = true;
            }
        } else d.water = 0;

        if (bad && d.lastGround != null && d.lastGround.getWorld().equals(to.getWorld())) {
            Location back = d.lastGround.clone();
            back.setYaw(to.getYaw());
            back.setPitch(to.getPitch());
            e.setTo(back);
            d.air = 0;
            d.climb = 0;
        }
    }

    private boolean nearGround(Location l) {
        World w = l.getWorld();
        int y = (int) Math.floor(l.getY() - 0.1);
        for (double x : OFF)
            for (double z : OFF) {
                Block b = w.getBlockAt((int) Math.floor(l.getX() + x), y, (int) Math.floor(l.getZ() + z));
                if (b.isSolid() || b.isCollidable()) return true;
            }
        return false;
    }

    private boolean special(Location l) {
        for (double y : new double[]{-0.1, 0, 1}) {
            Block b = l.clone().add(0, y, 0).getBlock();
            Material m = b.getType();
            if (b.isLiquid() || Tag.CLIMBABLE.isTagged(m) || SPECIAL.contains(m)) return true;
        }
        return false;
    }

    private boolean onEntity(Player p) {
        for (Entity en : p.getNearbyEntities(1.2, 2, 1.2))
            if (en instanceof Vehicle || en instanceof Shulker) return true;
        return false;
    }

    // ------------------------------------------------------------------ combat
    @EventHandler(ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p) || exempt(p)) return;
        if (e.getCause() == DamageCause.ENTITY_SWEEP_ATTACK) return;
        Entity v = e.getEntity();
        BoundingBox bb = v.getBoundingBox();
        Vector eye = p.getEyeLocation().toVector();
        Vector near = new Vector(clamp(eye.getX(), bb.getMinX(), bb.getMaxX()),
                clamp(eye.getY(), bb.getMinY(), bb.getMaxY()),
                clamp(eye.getZ(), bb.getMinZ(), bb.getMaxZ()));
        double reach = eye.distance(near);
        Data d = d(p);
        if (reach > reachLimit) {
            flag(p, d, "Reach (" + String.format("%.2f", reach) + ")", 3, true);
            e.setCancelled(true);
        } else if (!p.hasLineOfSight(v)) {
            flag(p, d, "Hit through wall", 1, true);
        }
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    @EventHandler
    public void onSwing(PlayerAnimationEvent e) {
        Player p = e.getPlayer();
        if (p.hasPermission("guard.bypass")) return;
        Data d = d(p);
        long now = System.currentTimeMillis();
        d.swings.addLast(now);
        while (!d.swings.isEmpty() && now - d.swings.peekFirst() > 1000) d.swings.pollFirst();
        if (d.swings.size() > maxCps)
            flag(p, d, "AutoClicker (" + d.swings.size() + " CPS)", 2, true);
    }

    // ------------------------------------------------------- nuker + x-ray heuristic
    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        if (p.getGameMode() == GameMode.CREATIVE || p.hasPermission("guard.bypass")) return;
        Data d = d(p);
        long now = System.currentTimeMillis();
        d.breaks.addLast(now);
        while (!d.breaks.isEmpty() && now - d.breaks.peekFirst() > 1000) d.breaks.pollFirst();
        if (d.breaks.size() > 18) {
            flag(p, d, "Nuker/FastBreak", 3, true);
            e.setCancelled(true);
            return;
        }
        Material m = e.getBlock().getType();
        boolean ore = VALUABLE.contains(m);
        if (ore || Tag.BASE_STONE_OVERWORLD.isTagged(m) || m == Material.NETHERRACK) {
            d.mined++;
            if (ore) d.ores++;
            if (d.mined >= 60) {
                if (d.ores >= 6) flag(p, d, "X-Ray suspicion (" + d.ores + " rare ores / 60 blocks)", 8, false);
                d.mined = 0;
                d.ores = 0;
            }
        }
    }

    // --------------------------------------------------------------- anti-ESP
    private void espTick() {
        for (Player v : Bukkit.getOnlinePlayers()) {
            if (v.hasPermission("guard.bypass")) continue;
            Data dv = d(v);
            Location eye = v.getEyeLocation();
            for (Player t : v.getWorld().getPlayers()) {
                if (t == v) continue;
                boolean visible = v.getGameMode() == GameMode.SPECTATOR || canSee(eye, t);
                boolean isHidden = dv.hidden.contains(t.getUniqueId());
                if (visible && isHidden) {
                    v.showEntity(this, t);
                    dv.hidden.remove(t.getUniqueId());
                } else if (!visible && !isHidden) {
                    v.hideEntity(this, t);
                    dv.hidden.add(t.getUniqueId());
                }
            }
        }
    }

    private boolean canSee(Location eye, Player t) {
        Location tl = t.getLocation();
        double dsq = eye.distanceSquared(tl);
        if (dsq < 36 || dsq > espMax * espMax || t.isGlowing()) return true;
        for (double h : HS)
            for (double[] o : OFFS) {
                double dx = tl.getX() + o[0] - eye.getX(), dy = tl.getY() + h - eye.getY(),
                        dz = tl.getZ() + o[1] - eye.getZ();
                double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
                if (len < 0.5) return true;
                RayTraceResult r = eye.getWorld().rayTraceBlocks(eye,
                        new Vector(dx / len, dy / len, dz / len), len, FluidCollisionMode.NEVER, true);
                if (r == null) return true;
            }
        return false;
    }

    // ------------------------------------------------------------ grace events
    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Data x = d(e.getPlayer());
        x.lastGround = e.getPlayer().getLocation();
        x.lastTeleport = System.currentTimeMillis();
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        data.remove(id);
        data.values().forEach(x -> x.hidden.remove(id));
    }

    @EventHandler
    public void onTeleport(PlayerTeleportEvent e) {
        Data x = d(e.getPlayer());
        x.lastTeleport = System.currentTimeMillis();
        x.lastGround = e.getTo().clone();
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Data x = d(e.getPlayer());
        x.lastTeleport = System.currentTimeMillis();
        x.lastGround = e.getRespawnLocation().clone();
    }

    @EventHandler
    public void onVelocity(PlayerVelocityEvent e) {
        d(e.getPlayer()).lastVelocity = System.currentTimeMillis();
    }

    @EventHandler
    public void onRiptide(PlayerRiptideEvent e) {
        d(e.getPlayer()).lastVelocity = System.currentTimeMillis();
    }

    @EventHandler
    public void onGlide(EntityToggleGlideEvent e) {
        if (e.getEntity() instanceof Player p) d(p).lastTeleport = System.currentTimeMillis();
    }

    // ------------------------------------------------------------ flag + command
    private void flag(Player p, Data d, String check, double add, boolean punish) {
        d.vl += add;
        long now = System.currentTimeMillis();
        Long last = d.alerts.get(check);
        if (last == null || now - last > 2000) {
            d.alerts.put(check, now);
            String txt = "[Guard] " + p.getName() + " failed " + check + " (VL " + String.format("%.1f", d.vl) + ")";
            Component msg = Component.text(txt, NamedTextColor.RED);
            for (Player s : Bukkit.getOnlinePlayers())
                if (s.hasPermission("guard.alerts")) s.sendMessage(msg);
            getLogger().warning(txt);
        }
        if (punish && d.vl >= kickVl) {
            d.vl = 0;
            p.kick(Component.text("Kicked by anti-cheat."));
        }
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!s.hasPermission("guard.admin")) return true;
        if (a.length > 0 && a[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            loadCfg();
            s.sendMessage("Guard config reloaded.");
        } else if (a.length > 1 && a[0].equalsIgnoreCase("vl")) {
            Player t = Bukkit.getPlayerExact(a[1]);
            s.sendMessage(t == null ? "Player not online." : t.getName() + " VL: " + String.format("%.1f", d(t).vl));
        } else s.sendMessage("/guard vl <player> | reload");
        return true;
    }
}
